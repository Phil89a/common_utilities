from pydantic import BaseModel, Field, model_validator
from typing import Optional
from datetime import datetime

class MQTTSensorPayload(BaseModel):
    read_at: datetime
    sensor_name: str = Field(..., alias="name")
    import_cumulative: Optional[float] = 0.0
    import_day: Optional[float] = None
    import_week: Optional[float] = 0.0
    import_month: Optional[float] = 0.0
    export_cumulative: Optional[float] = 0.0
    power_value: Optional[float] = 0.0
    power_units: Optional[str] = "kW"

    @model_validator(mode="before")
    @classmethod
    def unpack_nested(cls, data):
        # Auto-detect nested meter format (e.g., {'electricitymeter': {...}} or {'gasmeter': {...}})
        for key in ('electricitymeter', 'gasmeter'):
            if key in data:
                meter_data = data[key]
                return {
                    "read_at": meter_data.get("timestamp"),
                    "sensor_name": key,
                    "import_cumulative": meter_data.get("energy", {}).get("import", {}).get("cumulative"),
                    "import_day": meter_data.get("energy", {}).get("import", {}).get("day"),
                    "import_week": meter_data.get("energy", {}).get("import", {}).get("week"),
                    "import_month": meter_data.get("energy", {}).get("import", {}).get("month"),
                    "export_cumulative": meter_data.get("energy", {}).get("export", {}).get("cumulative"),
                    "power_value": meter_data.get("power", {}).get("value"),
                    "power_units": meter_data.get("power", {}).get("units", "kW"),
                }

        raise ValueError("Expected top-level key 'electricitymeter' or 'gasmeter'")

    model_config = {
        "populate_by_name": True,
        "from_attributes": True,
    }