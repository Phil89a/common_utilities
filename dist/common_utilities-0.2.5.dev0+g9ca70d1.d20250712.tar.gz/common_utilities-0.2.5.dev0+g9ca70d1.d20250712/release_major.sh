#!/bin/bash
set -e
python3 bump_version.py major