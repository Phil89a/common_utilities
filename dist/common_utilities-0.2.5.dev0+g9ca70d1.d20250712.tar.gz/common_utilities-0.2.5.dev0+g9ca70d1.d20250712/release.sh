#!/bin/bash
set -e

# Get version from Python
VERSION=$(python -c "import common_utilities; print(f'v{common_utilities.__version__}')")

# Commit, tag, and push
git add common_utilities/__init__.py
git commit -m "Release $VERSION"
git tag $VERSION
git push origin main
git push origin $VERSION

# Create GitHub Release (requires GitHub CLI)
gh release create $VERSION -t "$VERSION" -n "Auto-release for $VERSION"

echo "✅ Released version $VERSION"